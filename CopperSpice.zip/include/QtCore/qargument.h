#error Header file "qobjectdefs.h" removed in CS
