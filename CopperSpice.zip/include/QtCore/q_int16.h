#include <qglobal.h>
