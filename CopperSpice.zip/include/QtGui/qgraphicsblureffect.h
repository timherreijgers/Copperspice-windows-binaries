#include <qgraphicseffect.h>
