#include <qaccessibleplugin.h>
