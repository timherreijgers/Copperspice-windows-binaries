#include "qpalette.h"
